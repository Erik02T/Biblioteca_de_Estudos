# Documento misto F10 日本語

###### Título legado H6

Teoria 日本語 e fontes[Página fora do pacote]

```python
  const valor = "日本語";
	console.log(valor);
```

- [x] Tarefa A 日本語
- [ ] Tarefa B

### Exemplos

Dentro um

Dentro dois

> Explicação preservada



[Página fora do pacote]

![Arquivo](files/9dc843e9-ef7a-43b6-b70e-190a507c111f.png)



[Arquivo](files/1eabf9c8-39e0-4d0c-bd1a-b050c2b5306c.txt)



[Arquivo](https://example.com/f10-material)



Pendência antes da referência 日本語


## Materiais

[anotacao-f10.txt](files/1eabf9c8-39e0-4d0c-bd1a-b050c2b5306c.txt)

[https://example.com/f10-material](https://example.com/f10-material)

![imagem-f10.png](files/65ca4639-c6b7-49e4-8835-33c1e7955493.png)

![imagem-f10.png](files/9dc843e9-ef7a-43b6-b70e-190a507c111f.png)

[anotacao-f10.txt](files/c77d94df-9cd3-4d2b-897b-0b984d49afb4.txt)

[https://example.com/f10-material](https://example.com/f10-material)