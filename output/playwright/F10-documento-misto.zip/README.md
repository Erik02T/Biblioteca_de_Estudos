# Biblioteca de Estudos

Abra pages/<ID>/page.md em um leitor Markdown. Os arquivos estão em pastas relativas. O JSON preserva o conteúdo fonte; este pacote não inclui histórico de versões nem permite importação automática. Consulte manifest.json para hierarquia, hashes e limitações.
