# Título pendente UX-05

**Es**tudo 日本語 — texto real que será preservado. Texto novo do autosave.


## Materiais

[Material_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_.pdf](files/e2230620-f8e0-46bc-be68-56fb28b1b281.pdf)

[Material_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_.pdf](files/e2edb74d-1ed5-4d6d-8a22-1e56869b990b.pdf)