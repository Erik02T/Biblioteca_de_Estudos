# Título pendente UX-05

**Es**tudo 日本語 — texto real que será preservado. Texto novo do autosave.


## Materiais

[Material_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_.pdf](files/9375fc25-51a7-4cca-b3f8-ef0304c48641.pdf)

[Material_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_nome_longo_.pdf](files/c0411055-7324-474a-926b-6c06d20f04f1.pdf)