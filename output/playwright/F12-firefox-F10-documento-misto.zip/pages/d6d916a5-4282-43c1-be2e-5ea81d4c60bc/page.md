# Documento misto F10 日本語

###### Título legado H6

Teoria 日本語 e fontes[Página fora do pacote]

```python
  const valor = "日本語";
	console.log(valor);
```

- [x] Tarefa A 日本語
- [ ] Tarefa B

### Exemplos

Dentro um

Dentro dois

> Explicação preservada



[Página fora do pacote]

![Arquivo](files/d15ac183-e29e-402b-b335-a2c959096b8e.png)



[Arquivo](files/0097e6c4-13ef-49d7-a65a-4238ca0344d6.txt)



[Arquivo](https://example.com/f10-material)



Pendência antes da referência 日本語


## Materiais

[anotacao-f10.txt](files/0097e6c4-13ef-49d7-a65a-4238ca0344d6.txt)

[anotacao-f10.txt](files/4809d90e-9b8d-43b2-9983-0a011bf0917c.txt)

![imagem-f10.png](files/7b10dafd-df46-4226-9e5e-e4de1eca5b5f.png)

[https://example.com/f10-material](https://example.com/f10-material)

[https://example.com/f10-material](https://example.com/f10-material)

![imagem-f10.png](files/d15ac183-e29e-402b-b335-a2c959096b8e.png)